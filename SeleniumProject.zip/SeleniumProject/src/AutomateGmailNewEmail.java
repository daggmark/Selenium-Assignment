import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import java.util.concurrent.TimeUnit;

public class AutomateGmailNewEmail {
    private WebDriver driver;
    private String baseUrl;

    @Before
    public void setUp() throws Exception {
        System.setProperty("webdriver.chrome.driver","/usr/local/share/chromedriver");
        driver = new ChromeDriver();
        baseUrl = "https://www.gmail.com/";
        driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
    }

    @Test
    public void testEmailNotificationTestCase() throws Exception {
        driver.get(baseUrl);
        WebElement emailInput = driver.findElement(By.xpath("//*[@id=\"identifierId\"]"));
        emailInput.sendKeys("email@gmail.com");
        WebElement nextBtn = driver.findElement(By.xpath("//*[@id=\"identifierNext\"]"));
        nextBtn.click();
        WebElement passwordInput = driver.findElement(By.xpath("//input[@name='password']"));
        passwordInput.sendKeys("password");
        WebElement loginBtn = driver.findElement(By.xpath("//div[@id='passwordNext']"));
        loginBtn.click();

        WebElement notificationSpan = driver.findElement(By.xpath("//a[@href='https://mail.google.com/mail/u/0/#inbox']"));
        String notifications = notificationSpan.getText();

        String[] notifiStringParts = notifications.split("\\(");
        String[] notifiStringParts2 = notifiStringParts[1].split("\\)");

        System.out.printf("You have " + notifiStringParts2[0] + " notification.");
    }

    @After
    public void tearDown() throws Exception {
        driver.quit();
    }
}
